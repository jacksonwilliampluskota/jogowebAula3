/// <reference path="globals/ejs/index.d.ts" />
/// <reference path="globals/express/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
